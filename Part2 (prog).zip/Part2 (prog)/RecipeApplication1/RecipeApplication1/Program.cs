﻿using System;
using System.Collections.Generic;

namespace RecipeApp
{
    class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
        public double Calories { get; set; }
        public string FoodGroup { get; set; }
    }

    class RecipeStep
    {
        public string Description { get; set; }
    }

    class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; }
        public List<RecipeStep> Steps { get; set; }

        public void AddIngredients()
        {
            Console.WriteLine("Enter the number of ingredients:");
            int ingredientCount;
            while (!int.TryParse(Console.ReadLine(), out ingredientCount) || ingredientCount <= 0)
            {
                Console.WriteLine("Invalid input. Please enter a positive integer for the number of ingredients.");
            }

            Ingredients = new List<Ingredient>();

            for (int i = 0; i < ingredientCount; i++)
            {
                Console.WriteLine($"Enter ingredient {i + 1} details:");
                Console.Write("Name: ");
                string name = Console.ReadLine();
                Console.Write("Quantity: ");
                double quantity;
                while (!double.TryParse(Console.ReadLine(), out quantity) || quantity <= 0)
                {
                    Console.WriteLine("Invalid input. Please enter a positive number for the quantity.");
                }
                Console.Write("Unit: ");
                string unit = Console.ReadLine();
                Console.Write("Calories: ");
                double calories;
                while (!double.TryParse(Console.ReadLine(), out calories) || calories <= 0)
                {
                    Console.WriteLine("Invalid input. Please enter a positive number for the calories.");
                }
                Console.Write("Food Group: ");
                string foodGroup = Console.ReadLine();

                Ingredients.Add(new Ingredient { Name = name, Quantity = quantity, Unit = unit, Calories = calories, FoodGroup = foodGroup });
            }
        }

        public void AddSteps()
        {
            Console.WriteLine("Enter the number of steps:");
            int stepCount;
            while (!int.TryParse(Console.ReadLine(), out stepCount) || stepCount <= 0)
            {
                Console.WriteLine("Invalid input. Please enter a positive integer for the number of steps.");
            }

            Steps = new List<RecipeStep>();

            for (int i = 0; i < stepCount; i++)
            {
                Console.WriteLine($"Enter step {i + 1} description:");
                string description = Console.ReadLine();

                Steps.Add(new RecipeStep { Description = description });
            }
        }

        public void DisplayRecipe()
        {
            Console.WriteLine($"Recipe: {Name}");
            Console.WriteLine("Ingredients:");
            foreach (var ingredient in Ingredients)
            {
                Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name} ({ingredient.Calories} calories, {ingredient.FoodGroup})");
            }

            Console.WriteLine("\nSteps:");
            for (int i = 0; i < Steps.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {Steps[i].Description}");
            }
        }

        public double CalculateTotalCalories()
        {
            double totalCalories = 0;
            foreach (var ingredient in Ingredients)
            {
                totalCalories += ingredient.Calories;
            }
            return totalCalories;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("How many guests are coming? ");
            int numberOfGuests;
            while (!int.TryParse(Console.ReadLine(), out numberOfGuests) || numberOfGuests <= 0)
            {
                Console.WriteLine("Invalid input. Please enter a positive integer for the number of guests.");
            }

            List<Recipe> recipes = new List<Recipe>();

            while (true)
            {
                Recipe recipe = new Recipe();

                Console.Write("Enter recipe name: ");
                recipe.Name = Console.ReadLine();

                recipe.AddIngredients();
                recipe.AddSteps();

                recipes.Add(recipe);

                Console.Write("Do you want to enter another recipe? (yes/no): ");
                string choice = Console.ReadLine();
                if (choice.ToLower() != "yes")
                    break;
            }

            recipes.Sort((x, y) => string.Compare(x.Name, y.Name)); // Sort recipes by name

            Console.WriteLine("\nAll recipes:");
            foreach (var recipe in recipes)
            {
                Console.WriteLine(recipe.Name);
            }

            Console.Write("\nEnter the name of the recipe you want to display: ");
            string recipeName = Console.ReadLine();
            Recipe selectedRecipe = recipes.Find(r => r.Name == recipeName);
            if (selectedRecipe != null)
            {
                selectedRecipe.DisplayRecipe();
                double totalCalories = selectedRecipe.CalculateTotalCalories();
                Console.WriteLine($"\nTotal Calories: {totalCalories}");
                if (totalCalories > 300)
                {
                    Console.WriteLine("Warning: Total calories exceed 300!");
                }
            }
            else
            {
                Console.WriteLine("Recipe not found.");
            }

            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey();
        }
    }
}
